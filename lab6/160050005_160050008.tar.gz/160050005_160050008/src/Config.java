
/**
 * Edit to provide your database credentials
 */
public class Config {
	public static final String url = "jdbc:postgresql://localhost:5050/whatasap";
	public static final String user = "sahil";
	public static final String password = "";
}
